wooShortcodeMeta={
	attributes:[
		{
			label:"Email to send form to",
			id:"email", 
			help:"Defaults to the 'Contact Form E-mail' setting under 'Theme Options' if not set here"
		},
		{
			label:"Subject",
			id:"subject",
			help:"Defaults to 'Message from the contact form' if not set here"
		}
		],
		defaultContent:"",
		shortcode:"contact_form"
};
